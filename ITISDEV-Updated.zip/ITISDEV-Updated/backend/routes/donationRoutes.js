
const express = require('express');
const router = express.Router();
const Donation = require('../models/donationModel'); // Ensure correct path

// POST route to handle donations
router.post('/', async (req, res) => {
  try {
    const { numberOfTrees } = req.body;

    if (!numberOfTrees || numberOfTrees < 1) {
      return res.status(400).send('Valid number of trees is required.');
    }

    // Calculate amount based on number of trees (1 tree = 50 PHP)
    const amount = numberOfTrees * 50;

    // Create a new donation instance with the calculated amount
    const donation = new Donation({ numberOfTrees, amount });

    // Save the donation to the database
    await donation.save();

    // Respond to the client
    res.status(201).send('Donation successful!');
  } catch (error) {
    console.error(error); // Log the error for debugging
    res.status(500).send('Server error');
  }
});

module.exports = router;